#include "../Exercise03.hpp"

#include <gtest/gtest.h>



TEST(Exercise03Tests, zeroPermutation) {


    // input coin flip sequence
    bool inFlip[ARRAY_SIZE] = {
            false,
            true,
            false,
            true,
            false,
            true
    };

    // minimum number of permutations needed
    int nMinPer = 0;

    // get function call result
    const bool result = getMinPermutationsNumber(inFlip, ARRAY_SIZE, &nMinPer);

    // test start
    EXPECT_EQ(true, result);
    EXPECT_EQ(nMinPer, 0);
}


TEST(Exercise03Tests, twoPermutations) {


    // input coin flip sequence
    bool inFlip[ARRAY_SIZE] = {
            true,
            true,
            true,
            true,
            false,
            false
    };

    // minimum number of permutations needed
    int nMinPer = 0;

    // get function call result
    const bool result = getMinPermutationsNumber(inFlip, ARRAY_SIZE, &nMinPer);

    // test start
    EXPECT_EQ(true, result);
    EXPECT_EQ(nMinPer, 2);
}