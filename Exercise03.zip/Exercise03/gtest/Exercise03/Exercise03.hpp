#ifndef EXERCISE03_HPP
#define EXERCISE03_HPP

//
//      EXERCISE 3:
//      A function that given a sequence of coin flips (0 is tails, 1 is heads) finds
//      the minimum quantity of permutations so that the sequence ends interspersed.
//      For example,
//      given the sequence 0,1,1,0 how many changes are needed so that the result is 0,1,0,1
//
//
//



//
//      INCLUDE FILES
//
#include <iostream>
#include <assert.h>

using namespace std;

//
//      LOCAL DEFINES
//
#define DEBUG
#define ARRAY_SIZE 6U


//
//      FUNCTION PROTOTYPES
//
bool getMinPermutationsNumber(bool inFlip[], int size, int *nMinPer);






#endif /* EXERCISE03_HPP */
