//
//      EXERCISE 3:
//      A function that given a sequence of coin flips (0 is tails, 1 is heads) finds
//      the minimum quantity of permutations so that the sequence ends interspersed.
//      For example,
//      given the sequence 0,1,1,0 how many changes are needed so that the result is 0,1,0,1
//
//
//



//
//      INCLUDE FILES
//
#include <iostream>
#include <assert.h>

using namespace std;

//
//      LOCAL DEFINES
//
#define DEBUG
#define ARRAY_SIZE 6U


//
//      FUNCTION PROTOTYPES
//
bool getMinPermutationsNumber(bool inFlip[], int size, int *nMinPer);


//
//      main()
//
//      Description : This is the standard entry point of this exercise.
//      Arguments   : none
//      Returns     : none
//
int main() {

    // input coin flip sequence
    bool inFlip[ARRAY_SIZE] = {
            true,
            true,
            true,
            true,
            false,
            false
    };

    // minimum number of permutations needed
    int nMinPer = 0;

    // call function
    if (getMinPermutationsNumber(inFlip, ARRAY_SIZE, &nMinPer) != false) {

        cout << "Minimum number of permutations: " << nMinPer << endl;

    }
    else
    {
        // an error has occurred
    }
}



//
//      getMinPermutationsNumber()
//
//      Description : given a sequence of 1's and 0's, returns the minimum number of permutations
//                    to generate an interspersed sequence.
//      Argument(s) : inFlip    (in)     array of 1's and 0's.
//                    sizeFlip  (in)     size of inFlip array.
//                    nMinPer   (out)    minimum number of permutations.
//
//      Return(s)   : status                  true: minimum number of permutations calculated / false: function error.
//      Caller(s)   : main()
//

bool getMinPermutationsNumber(bool inFlip[], int sizeFlip, int *nMinPer)
{

    // Iterators for inFlip array
    int i = 0;
    int j = 0;

    // Initialize the actual flip status and the next desired flip status
    bool actualFlip = false;
    bool nextExpectedFlip = !actualFlip;

    // Helps to break the loop if some permutation has been done
    bool permutation_done = false;

    // auxiliary flip status swap
    bool tempFlip = false;



#ifdef DEBUG
    // Show contents of the array
    cout << "----------------" << endl;
    for (int t=0; t < sizeFlip; t++) {
        cout << inFlip[t] << "  ";
    }
    cout << endl << "----------------" << endl;
#endif


    // Get the size of the input flip sequence
    int inFlipsize = sizeFlip;

    // Exit if empty sequence or no sequence
    assert(inFlipsize > 2);

    // First flip defines whether first element starts with '0' or '1'
    actualFlip = inFlip[0];
    nextExpectedFlip = !actualFlip;

#ifdef DEBUG
    cout << "actualFlip: " << actualFlip << "  " << "nextExpectedFlip: " << nextExpectedFlip << endl;
#endif

    // Start to analyse the rest of the flip sequence
    i=1;
    j=1;

    // End of the sequence reached?
    while (i < inFlipsize) {

        // flip value is as expected?
        if (inFlip[i] == nextExpectedFlip) {

            // next flip value is as expected, we keep it.
#ifdef DEBUG
            cout << "No permutation needed" << endl;
#endif
        }
        else {

            // next flip value is NOT as expected, we need to permutate it.
#ifdef DEBUG
            cout << "Permutation needed" << endl;
#endif
            // Set permutation as NOT done
            permutation_done = false;

            // In the flip sequence, search for a convenient flip value to swap
            while ((j < inFlipsize) && !permutation_done) {

                // if this flip value convenient to build the sequence?
                if (inFlip[j] == nextExpectedFlip) {

                    // yes, swap it.
#ifdef DEBUG
                    cout << "Permutation founded. Positions to permutate : i->" << i << ", j->" << j << endl;
#endif
                    // Done permutation
                    tempFlip = inFlip[i];
                    inFlip[i] = inFlip[j];
                    inFlip[j] = tempFlip;

                    // Set permutation as done
                    permutation_done = true;
#ifdef DEBUG
                    cout << "Permutation done" << endl;
#endif
                    // Record new permutation
                    *nMinPer+=1;


#ifdef DEBUG
                    // Show contents of the array
                    cout << "----------------" << endl;
                    for (int t=0; t < sizeFlip; t++) {
                        cout << inFlip[t] << "  ";
                    }
                    cout << endl << "----------------" << endl;
#endif

                }
                else {

                    // no convenient, continue to search through the flip sequence
                    j++;

                }


            } // end of flip sequence


        } // end if

        // update next desired flip value
        actualFlip = inFlip[i];
        nextExpectedFlip = !actualFlip;

#ifdef DEBUG
        cout << "Setup next search --> actualFlip: " << actualFlip << "  " << "nextExpectedFlip: " << nextExpectedFlip << endl;
#endif

        // move on to the next flip value of the flip sequence
        i++;

    } // end of flip sequence

#ifdef DEBUG
    // Show contents of the array
    cout << "----------------" << endl;
    for (int t=0; t < sizeFlip; t++) {
        cout << inFlip[t] << "  ";
    }
    cout << endl << "----------------" << endl;
#endif

    return true;


}



