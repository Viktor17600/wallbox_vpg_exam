#ifndef EXERCISE02_HPP
#define EXERCISE02_HPP

//
//      EXERCISE 2:
//      A function that given a path of the file system finds the first file that meets the
//      following requirements:
//          a. The file owner is admin
//          b. The file is executable
//          c. The file has a size lower than 14*2^20


//
//      INCLUDE FILES
//
#include <iostream>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <sys/stat.h>
#include <unistd.h>

using namespace std;

//
//      LOCAL DEFINES
//
//#define DEBUG
#define OWNER_ATTR      501U    // owner requirement     : admin (code 80)
#define SIZE_LIMIT 14680064U    // size requirement      : lower than 14*2^20
#define EXEC_ATTR      X_OK     // attribute requirement : executable file
#define AUX_STR_LEN     400U    // buffer length for the auxiliary string


//
//      FUNCTION PROTOTYPES
//
bool getFileFromPath(char *, char *);


#endif /* EXERCISE02_HPP */
