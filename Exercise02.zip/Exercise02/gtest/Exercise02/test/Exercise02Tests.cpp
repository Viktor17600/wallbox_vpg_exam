#include "../Exercise02.hpp"

#include <gtest/gtest.h>



TEST(Exercise02Tests, noCompliantFile) {


    // Initialize the input path
    char path[] = "/home/";

    // Initialize the resulted compliant file
    char compliantFile[] = "";

    // get function call result
    const bool result = getFileFromPath(path, compliantFile);

    // test start
    EXPECT_EQ(false, result);
    EXPECT_STREQ(compliantFile, "");
}


TEST(Exercise02Tests, CompliantFile) {


    // Initialize the input path
    char path[] = "/sbin/";

    // Initialize the resulted compliant file
    char compliantFile[] = "";

    // get function call result
    const bool result = getFileFromPath(path, compliantFile);

    // test start
    EXPECT_EQ(true, result);
    EXPECT_STRNE(compliantFile, "");
}