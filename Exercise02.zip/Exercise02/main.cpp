//
//      EXERCISE 2:
//      A function that given a path of the file system finds the first file that meets the
//      following requirements:
//          a. The file owner is admin
//          b. The file is executable
//          c. The file has a size lower than 14*2^20


//
//      INCLUDE FILES
//
#include <iostream>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <sys/stat.h>
#include <unistd.h>

using namespace std;

//
//      LOCAL DEFINES
//
//#define DEBUG
#define OWNER_ATTR       80U    // owner requirement     : admin (code 80)
#define SIZE_LIMIT 14680064U    // size requirement      : lower than 14*2^20
#define EXEC_ATTR      X_OK     // attribute requirement : executable file
#define AUX_STR_LEN     400U    // buffer length for the auxiliary string


//
//      FUNCTION PROTOTYPES
//
bool getFileFromPath(char *, char *);


//
//      main()
//
//      Description : This is the standard entry point of this exercise.
//      Arguments   : none
//      Returns     : none
//
int main() {

    // Initialize the input path
    char path[] = "/";

    // Initialize the resulted compliant file
    char compliantFile[] = "";

    // Search for the first compliant file, if any.
    if (getFileFromPath(path, compliantFile)) {

        cout << "First compliant file is : " << compliantFile << endl;

    }
    else {

        cout << "No compliant file found. " << endl;

    }
}


//
//      getFileFromPath()
//
//      Description : given a path of the file system finds the first file that meets the
//      following requirements,
//          a. The file owner is admin (code : 80)
//          b. The file is executable
//          c. The file has a size lower than 14*2^20
//
//      Argument(s) : filePath (in)       Directory where to search for a compliant files.
//                    fileOut  (out)      Name of first compliant file found.
//
//
//      Return(s)   : status              true: one compliant file found / false: any compliant file found.
//      Caller(s)   : main()
//
bool getFileFromPath(char *filePath, char *fileOut)
{
    // Directory manager variables
    struct dirent *file;
    struct stat fileAttributes;
    DIR *path;

    // compliant file detection flag
    bool fileFound = false;

    // auxiliary variables for the construction of the absolute path string
    char auxString[AUX_STR_LEN];
    char *absPath;

    // Open searching path
    path = opendir(filePath);

    // Exit if erroneous path
    assert(path != NULL);

    // Iterate files contained into the searching path
    while ( ((file=readdir(path)) != NULL) && (!fileFound)) {

        // absolute path construction of the current file
        absPath = auxString;
        strcpy(absPath,filePath);
        strcat(absPath, file->d_name);

#ifdef DEBUG
        cout << "absPath: " << absPath << endl;
#endif

        // Get file attributes
        if (stat(absPath, &fileAttributes) == 0) {

#ifdef DEBUG
            // "read" attribute
            if (fileAttributes.st_mode & R_OK)
                cout << "read attribute" << endl;

            // "write" attribute
            if (fileAttributes.st_mode & W_OK)
                cout << "write attribute" << endl;

            // "execute" attribute
            if (fileAttributes.st_mode & X_OK)
                cout << "execute attribute" << endl;

            // File size
            cout << "File size: " << fileAttributes.st_size << endl;

            // File owner (admin code: 80)
            cout << "File owner: " << fileAttributes.st_uid << endl;
#endif

            // is this file compliant ?
            if ( (fileAttributes.st_mode & EXEC_ATTR) && (fileAttributes.st_uid == OWNER_ATTR) && (fileAttributes.st_size < SIZE_LIMIT) ) {

                // yes, file is compliant, then, return name of the file...
                strcpy(fileOut,file->d_name);

                // ...and raise the flag
                fileFound = true;
            }
        }
        else
        {
            // Error accessing to file attributes
            cout << "Unable to get file properties" << endl;
            cout << "Please check whether " << absPath << " file exists" << endl;
        }

    }

    // close handler to directory
    closedir(path);

    // set the return value for this function
    if (fileFound)
        return true;
    else
        return false;

}