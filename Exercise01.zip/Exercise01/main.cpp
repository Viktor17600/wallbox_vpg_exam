//
//      EXERCISE 1:
//      A function that given two vectors of integers finds the first repeated number
//
//
//


//
//      INCLUDE FILES
//
#include <iostream>
#include <vector>
#include <assert.h>

using namespace std;


//
//      LOCAL DEFINES
//
//#define DEBUG


//
//      FUNCTION PROTOTYPES
//
bool getFirstRepeatedNumber (vector <int>, vector <int>, int *);


//
//      main()
//
//      Description : This is the standard entry point of this exercise.
//      Arguments   : none
//      Returns     : none
//
int main() {

    // First integer vector creation
    vector<int> FirstVector{
            1,
            2,
            3
    };

    // Second integer vector creation
    vector<int> SecondVector{
            4,
            5,
            3,
            7,
            8
    };

    // Return value
    int value = 0;

#ifdef DEBUG

    cout << "----------------" << endl;
    // Show contents from first vector
    for (int x: FirstVector)
        cout << x << endl;

    cout << "Size of the first vector is :" << FirstVector.size() << endl;
    cout << "----------------" << endl;

    // Show contents from second vector
    for (int x: SecondVector)
        cout << x << endl;

    cout << "Size of the second vector is :" << SecondVector.size() << endl;
    cout << "----------------" << endl;

#endif

    // Get repeated number, if any.
    if (getFirstRepeatedNumber(FirstVector, SecondVector, &value)) {

        cout << "First repeated number is : " << value << endl;

    }
    else {

        cout << "No repeated number found. " << endl;

    }
}


//
//      getFirstRepeatedNumber()
//
//      Description : given two vectors of integers returns the first repeated number.
//      Argument(s) : FirstVector    (in)     First vector of integers for check.
//                    SecondVector   (in)     Second vector of integers for check.
//                    value          (out)    First repeated number inside both vectors.
//
//      Return(s)   : status                  true: repeated number found / false: No repeated number found
//      Caller(s)   : main()
//
bool getFirstRepeatedNumber(vector <int> FirstVector, vector <int> SecondVector, int *value)
{

    // Exit if empty vectors
    assert(FirstVector.size() != 0 && SecondVector.size() != 0);

    // Point to the first element of first vector
    vector<int>::iterator first;
    first = FirstVector.begin();

    // Point to the first element of second vector
    vector<int>::iterator second;
    second = SecondVector.begin();

    // Iterate between both vectors
    while (first != FirstVector.end()) {

        while (second != SecondVector.end()) {

#ifdef DEBUG
            cout << "[" << *first << "," << *second << "]" << endl;
#endif

            if (*first == *second) {
                *value = *first;
                return true; // repetition found
            }


            *second++;

        }
        second = SecondVector.begin();

        *first++;
    }

    return false; // not repetition found
}