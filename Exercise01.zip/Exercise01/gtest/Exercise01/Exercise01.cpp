 #include "Exercise01.hpp"


//
//      EXERCISE 1:
//      A function that given two vectors of integers finds the first repeated number
//
//
//


 

//
//      getFirstRepeatedNumber()
//
//      Description : given two vectors of integers returns the first repeated number.
//      Argument(s) : FirstVector    (in)     First vector of integers for check.
//                    SecondVector   (in)     Second vector of integers for check.
//                    value          (out)    First repeated number inside both vectors.
//
//      Return(s)   : status                  true: repeated number found / false: No repeated number found
//      Caller(s)   : main()
//
bool getFirstRepeatedNumber(vector <int> FirstVector, vector <int> SecondVector, int *value)
{

    // Exit if empty vectors
    assert(FirstVector.size() != 0 && SecondVector.size() != 0);

    // Point to the first element of first vector
    vector<int>::iterator first;
    first = FirstVector.begin();

    // Point to the first element of second vector
    vector<int>::iterator second;
    second = SecondVector.begin();

    // Iterate between both vectors
    while (first != FirstVector.end()) {

        while (second != SecondVector.end()) {

#ifdef DEBUG
            cout << "[" << *first << "," << *second << "]" << endl;
#endif

            if (*first == *second) {
                *value = *first;
                return true; // repetition found
            }


            *second++;

        }
        second = SecondVector.begin();

        *first++;
    }

    return false; // not repetition found
}
