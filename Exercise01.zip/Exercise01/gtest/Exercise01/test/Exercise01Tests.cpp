#include "../Exercise01.hpp"

#include <gtest/gtest.h>



TEST(Exercise01Tests, oneRepeated) {


    // First integer vector creation
    vector<int> FirstVector{
            1,
            2,
            3
    };

    // Second integer vector creation
    vector<int> SecondVector{
            4,
            5,
            3,
            7,
            8
    };

    // Return value
    int value = 0;

    // get function call result
    const bool result = getFirstRepeatedNumber(FirstVector, SecondVector, &value);

    // test start
    EXPECT_EQ(true, result);
    EXPECT_EQ(value, 3);
}


TEST(Exercise01Tests, anyRepeated) {


    // First integer vector creation
    vector<int> FirstVector{
            1,
            2,
            3
    };

    // Second integer vector creation
    vector<int> SecondVector{
            4,
            5,
            6,
            7,
            8
    };

    // Return value
    int value = 0;

    // get function call result
    const bool result = getFirstRepeatedNumber(FirstVector, SecondVector, &value);

    // test start
    EXPECT_EQ(false, result);
    EXPECT_EQ(value, 0);
}