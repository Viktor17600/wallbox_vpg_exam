#ifndef EXERCISE01_HPP
#define EXERCISE01_HPP

//
//      EXERCISE 1:
//      A function that given two vectors of integers finds the first repeated number
//
//
//


//
//      INCLUDE FILES
//
#include <iostream>
#include <vector>
#include <assert.h>

using namespace std;


//
//      LOCAL DEFINES
//
//#define DEBUG


//
//      FUNCTION PROTOTYPES
//
bool getFirstRepeatedNumber (vector <int>, vector <int>, int *);







#endif /* EXERCISE01_HPP */
